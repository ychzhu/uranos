/********************************************************************************
** Form generated from reading UI file 'visualizationenlarge.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VISUALIZATIONENLARGE_H
#define UI_VISUALIZATIONENLARGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_VisualizationEnlarge
{
public:
    QCustomPlot *customPlot;
    QPushButton *pushButtonPNG;

    void setupUi(QDialog *VisualizationEnlarge)
    {
        if (VisualizationEnlarge->objectName().isEmpty())
            VisualizationEnlarge->setObjectName(QStringLiteral("VisualizationEnlarge"));
        VisualizationEnlarge->resize(1212, 1052);
        VisualizationEnlarge->setMaximumSize(QSize(1250, 1052));
        customPlot = new QCustomPlot(VisualizationEnlarge);
        customPlot->setObjectName(QStringLiteral("customPlot"));
        customPlot->setGeometry(QRect(0, 0, 1211, 1052));
        customPlot->setMaximumSize(QSize(1250, 1052));
        pushButtonPNG = new QPushButton(customPlot);
        pushButtonPNG->setObjectName(QStringLiteral("pushButtonPNG"));
        pushButtonPNG->setGeometry(QRect(1140, 10, 61, 41));

        retranslateUi(VisualizationEnlarge);

        QMetaObject::connectSlotsByName(VisualizationEnlarge);
    } // setupUi

    void retranslateUi(QDialog *VisualizationEnlarge)
    {
        VisualizationEnlarge->setWindowTitle(QApplication::translate("VisualizationEnlarge", "Enlarged Visualization", Q_NULLPTR));
        pushButtonPNG->setText(QApplication::translate("VisualizationEnlarge", "URANOS\n"
"Export", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class VisualizationEnlarge: public Ui_VisualizationEnlarge {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VISUALIZATIONENLARGE_H
